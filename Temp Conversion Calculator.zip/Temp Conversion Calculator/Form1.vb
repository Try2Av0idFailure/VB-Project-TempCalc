﻿Public Class frmTempCalc
    Dim intCount As Integer = 0


    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        If TempBox.Text = "" Then
            MsgBox("Please enter a number to convert")
        End If
        If intCount < 4 Then

            Try
                Dim value As Double = Convert.ToDouble(TempBox.Text)

                If rdbtnF2Celcius.Checked Then
                    lblOutput.Text = Convert.ToString(Math.Round((value - 32) * (5 / 9)))
                ElseIf rdbtnF2Kelvin.Checked Then
                    lblOutput.Text = Convert.ToString(Math.Round((value - 32) * (5 / 9) + 273.15))
                ElseIf rdbtnC2Farenheit.Checked Then
                    lblOutput.Text = Convert.ToString(Math.Round((value + 32) * (9 / 5)))
                ElseIf rdbtnC2Kelvin.Checked Then
                    lblOutput.Text = Convert.ToString(Math.Round((value) + 273.15))
                End If

            Catch ex As Exception

            End Try

            Do Until intCount = 3
                intCount += 1
                lblList.Text = "Full"
                lstBoxOutputs.Items.Add(lblOutput.Text)

            Loop

        End If


    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        TempBox.Text = ""
        lblOutput.Text = ""
        lstBoxOutputs.Items.Clear()
        lblList.Text = "List Status"
        intCount = 0
    End Sub




End Class
