﻿Public Class frmTempCalc



    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        If FarenheitBox.Text = "" Then
            MsgBox("Pleae enter a number to convert")
        End If
        Try
            Dim value As Double = Convert.ToDouble(FarenheitBox.Text)


            If rdbtnCelcius.Checked Then
                lblOutput.Text = Convert.ToString(Math.Round((value - 32) * (5 / 9)))
            Else
                lblOutput.Text = Convert.ToString(Math.Round((value - 32) * (5 / 9) + 273.15))
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        FarenheitBox.Text = ""
        lblOutput.Text = ""
    End Sub
End Class
