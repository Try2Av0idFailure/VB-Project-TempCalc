﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTempCalc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FarenheitBox = New System.Windows.Forms.TextBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.rdbtnCelcius = New System.Windows.Forms.RadioButton()
        Me.grpBox1 = New System.Windows.Forms.GroupBox()
        Me.rdbtnKelvin = New System.Windows.Forms.RadioButton()
        Me.lblOutput = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(590, 345)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(715, 345)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Temp_Conversion_Calculator.My.Resources.Resources.themometer
        Me.PictureBox1.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(583, 573)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'FarenheitBox
        '
        Me.FarenheitBox.Location = New System.Drawing.Point(634, 232)
        Me.FarenheitBox.Name = "FarenheitBox"
        Me.FarenheitBox.Size = New System.Drawing.Size(122, 20)
        Me.FarenheitBox.TabIndex = 3
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(631, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(157, 13)
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.Text = "Farenheit Conversion Calculator"
        '
        'rdbtnCelcius
        '
        Me.rdbtnCelcius.AutoSize = True
        Me.rdbtnCelcius.Location = New System.Drawing.Point(16, 19)
        Me.rdbtnCelcius.Name = "rdbtnCelcius"
        Me.rdbtnCelcius.Size = New System.Drawing.Size(117, 17)
        Me.rdbtnCelcius.TabIndex = 5
        Me.rdbtnCelcius.TabStop = True
        Me.rdbtnCelcius.Text = "Farenheit to Celsius"
        Me.rdbtnCelcius.UseVisualStyleBackColor = True
        '
        'grpBox1
        '
        Me.grpBox1.Controls.Add(Me.rdbtnKelvin)
        Me.grpBox1.Controls.Add(Me.rdbtnCelcius)
        Me.grpBox1.Location = New System.Drawing.Point(590, 71)
        Me.grpBox1.Name = "grpBox1"
        Me.grpBox1.Size = New System.Drawing.Size(200, 100)
        Me.grpBox1.TabIndex = 6
        Me.grpBox1.TabStop = False
        '
        'rdbtnKelvin
        '
        Me.rdbtnKelvin.AutoSize = True
        Me.rdbtnKelvin.Location = New System.Drawing.Point(16, 60)
        Me.rdbtnKelvin.Name = "rdbtnKelvin"
        Me.rdbtnKelvin.Size = New System.Drawing.Size(113, 17)
        Me.rdbtnKelvin.TabIndex = 6
        Me.rdbtnKelvin.TabStop = True
        Me.rdbtnKelvin.Text = "Farenheit to Kelvin"
        Me.rdbtnKelvin.UseVisualStyleBackColor = True
        '
        'lblOutput
        '
        Me.lblOutput.AutoSize = True
        Me.lblOutput.Location = New System.Drawing.Point(631, 409)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(13, 13)
        Me.lblOutput.TabIndex = 7
        Me.lblOutput.Text = "L"
        '
        'frmTempCalc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(837, 586)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.grpBox1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.FarenheitBox)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmTempCalc"
        Me.Text = "Farenheight Conversion Calculator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpBox1.ResumeLayout(False)
        Me.grpBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents FarenheitBox As TextBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents rdbtnCelcius As RadioButton
    Friend WithEvents grpBox1 As GroupBox
    Friend WithEvents rdbtnKelvin As RadioButton
    Friend WithEvents lblOutput As Label
End Class
