﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTempCalc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TempBox = New System.Windows.Forms.TextBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.rdbtnF2Celcius = New System.Windows.Forms.RadioButton()
        Me.grpBox1 = New System.Windows.Forms.GroupBox()
        Me.rdbtnC2Kelvin = New System.Windows.Forms.RadioButton()
        Me.rdbtnC2Farenheit = New System.Windows.Forms.RadioButton()
        Me.rdbtnF2Kelvin = New System.Windows.Forms.RadioButton()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.lstBoxOutputs = New System.Windows.Forms.ListBox()
        Me.lblList = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(590, 345)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(715, 345)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Temp_Conversion_Calculator.My.Resources.Resources.themometer
        Me.PictureBox1.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(583, 573)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'TempBox
        '
        Me.TempBox.Location = New System.Drawing.Point(634, 251)
        Me.TempBox.Name = "TempBox"
        Me.TempBox.Size = New System.Drawing.Size(122, 20)
        Me.TempBox.TabIndex = 3
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(631, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(157, 13)
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.Text = "Farenheit Conversion Calculator"
        '
        'rdbtnF2Celcius
        '
        Me.rdbtnF2Celcius.AutoSize = True
        Me.rdbtnF2Celcius.Location = New System.Drawing.Point(16, 19)
        Me.rdbtnF2Celcius.Name = "rdbtnF2Celcius"
        Me.rdbtnF2Celcius.Size = New System.Drawing.Size(117, 17)
        Me.rdbtnF2Celcius.TabIndex = 5
        Me.rdbtnF2Celcius.TabStop = True
        Me.rdbtnF2Celcius.Text = "Farenheit to Celsius"
        Me.rdbtnF2Celcius.UseVisualStyleBackColor = True
        '
        'grpBox1
        '
        Me.grpBox1.Controls.Add(Me.rdbtnC2Kelvin)
        Me.grpBox1.Controls.Add(Me.rdbtnC2Farenheit)
        Me.grpBox1.Controls.Add(Me.rdbtnF2Kelvin)
        Me.grpBox1.Controls.Add(Me.rdbtnF2Celcius)
        Me.grpBox1.Location = New System.Drawing.Point(590, 71)
        Me.grpBox1.Name = "grpBox1"
        Me.grpBox1.Size = New System.Drawing.Size(200, 166)
        Me.grpBox1.TabIndex = 6
        Me.grpBox1.TabStop = False
        '
        'rdbtnC2Kelvin
        '
        Me.rdbtnC2Kelvin.AutoSize = True
        Me.rdbtnC2Kelvin.Location = New System.Drawing.Point(16, 133)
        Me.rdbtnC2Kelvin.Name = "rdbtnC2Kelvin"
        Me.rdbtnC2Kelvin.Size = New System.Drawing.Size(99, 17)
        Me.rdbtnC2Kelvin.TabIndex = 8
        Me.rdbtnC2Kelvin.TabStop = True
        Me.rdbtnC2Kelvin.Text = "Celsius toKelvin"
        Me.rdbtnC2Kelvin.UseVisualStyleBackColor = True
        '
        'rdbtnC2Farenheit
        '
        Me.rdbtnC2Farenheit.AutoSize = True
        Me.rdbtnC2Farenheit.Location = New System.Drawing.Point(16, 94)
        Me.rdbtnC2Farenheit.Name = "rdbtnC2Farenheit"
        Me.rdbtnC2Farenheit.Size = New System.Drawing.Size(117, 17)
        Me.rdbtnC2Farenheit.TabIndex = 7
        Me.rdbtnC2Farenheit.TabStop = True
        Me.rdbtnC2Farenheit.Text = "Celsius to Farenheit"
        Me.rdbtnC2Farenheit.UseVisualStyleBackColor = True
        '
        'rdbtnF2Kelvin
        '
        Me.rdbtnF2Kelvin.AutoSize = True
        Me.rdbtnF2Kelvin.Location = New System.Drawing.Point(16, 60)
        Me.rdbtnF2Kelvin.Name = "rdbtnF2Kelvin"
        Me.rdbtnF2Kelvin.Size = New System.Drawing.Size(113, 17)
        Me.rdbtnF2Kelvin.TabIndex = 6
        Me.rdbtnF2Kelvin.TabStop = True
        Me.rdbtnF2Kelvin.Text = "Farenheit to Kelvin"
        Me.rdbtnF2Kelvin.UseVisualStyleBackColor = True
        '
        'lblOutput
        '
        Me.lblOutput.AutoSize = True
        Me.lblOutput.Location = New System.Drawing.Point(631, 409)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(13, 13)
        Me.lblOutput.TabIndex = 7
        Me.lblOutput.Text = "L"
        '
        'lstBoxOutputs
        '
        Me.lstBoxOutputs.FormattingEnabled = True
        Me.lstBoxOutputs.Location = New System.Drawing.Point(705, 424)
        Me.lstBoxOutputs.Name = "lstBoxOutputs"
        Me.lstBoxOutputs.Size = New System.Drawing.Size(120, 121)
        Me.lstBoxOutputs.TabIndex = 9
        '
        'lblList
        '
        Me.lblList.AutoSize = True
        Me.lblList.Location = New System.Drawing.Point(606, 469)
        Me.lblList.Name = "lblList"
        Me.lblList.Size = New System.Drawing.Size(54, 13)
        Me.lblList.TabIndex = 10
        Me.lblList.Text = "List status"
        '
        'frmTempCalc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(837, 586)
        Me.Controls.Add(Me.lblList)
        Me.Controls.Add(Me.lstBoxOutputs)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.grpBox1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.TempBox)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmTempCalc"
        Me.Text = "Farenheight Conversion Calculator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpBox1.ResumeLayout(False)
        Me.grpBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TempBox As TextBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents rdbtnF2Celcius As RadioButton
    Friend WithEvents grpBox1 As GroupBox
    Friend WithEvents rdbtnF2Kelvin As RadioButton
    Friend WithEvents lblOutput As Label
    Friend WithEvents rdbtnC2Kelvin As RadioButton
    Friend WithEvents rdbtnC2Farenheit As RadioButton
    Friend WithEvents lstBoxOutputs As ListBox
    Friend WithEvents lblList As Label
End Class
